(() => {
  if (window.__qiuzhiApplyBridge) return;
  const origins = ['http://127.0.0.1:5173', 'http://localhost:5173', 'https://zhixiaoda.net'];
  if (!origins.includes(location.origin) || window !== window.top) return;
  window.__qiuzhiApplyBridge = true;
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || !['SAVE_PROFILE_ANSWER', 'VERIFY_APPLICATION_CONTEXT', 'APPLICATION_DECISION'].includes(message?.type)) return false;
    const listener = event => {
      if (event.source !== window || event.origin !== location.origin || event.data?.source !== 'qiuzhi-apply-web' ||
          event.data.type !== 'SAVE_RESULT' || event.data.requestId !== message.requestId) return;
      clearTimeout(timeout); window.removeEventListener('message', listener); respond(event.data);
    };
    const timeout = setTimeout(() => { window.removeEventListener('message', listener); respond({ ok: false, error: '工作台未响应，回答仍用于本轮，资料未保存。' }); }, ['APPLICATION_DECISION', 'SAVE_PROFILE_ANSWER'].includes(message.type) ? 100000 : 15000);
    window.addEventListener('message', listener);
    window.postMessage({ ...message, source: 'qiuzhi-apply-extension' }, location.origin);
    return true;
  });
  window.addEventListener('message', async event => {
    if (event.source !== window || event.origin !== location.origin) return;
    const request = event.data;
    if (request?.source !== 'qiuzhi-apply-web' || !['PING', 'START'].includes(request.type) ||
        typeof request.requestId !== 'string' || request.requestId.length > 64) return;
    if (request.type === 'PING') {
      window.postMessage({ source: 'qiuzhi-apply-extension', requestId: request.requestId,
        ok: Boolean(chrome.runtime.id), code: chrome.runtime.id ? undefined : 'UNAVAILABLE' }, location.origin);
      return;
    }
    let result;
    try {
      result = await chrome.runtime.sendMessage({ type: 'START_WEB_APPLY', requestId: request.requestId, job: request.job, context: request.context });
    } catch {
      result = { ok: false, code: 'UNAVAILABLE' };
    }
    window.postMessage({ source: 'qiuzhi-apply-extension', requestId: request.requestId,
      ok: result?.ok === true, code: result?.code }, location.origin);
  });
})();
