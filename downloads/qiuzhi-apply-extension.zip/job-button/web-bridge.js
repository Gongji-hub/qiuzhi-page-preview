(() => {
  const origins = ['http://127.0.0.1:5173', 'http://localhost:5173', 'https://zhixiaoda.net'];
  if (!origins.includes(location.origin) || window !== window.top) return;
  if (window.__qiuzhiApplyBridge?.isAlive?.()) return;
  window.__qiuzhiApplyBridge?.dispose?.();
  const runtime = chrome.runtime;
  const pending = new Set();
  let disposed = false;
  const isAlive = () => {
    try { return !disposed && Boolean(runtime.id); } catch { return false; }
  };
  const getVersion = () => {
    try { return runtime.getManifest?.()?.version || undefined; } catch { return undefined; }
  };
  const dispose = () => {
    disposed = true;
    window.removeEventListener('message', onWindowMessage);
    try { runtime.onMessage.removeListener(onRuntimeMessage); } catch { /* The old extension context is gone. */ }
    for (const cleanup of pending) cleanup();
  };
  const onRuntimeMessage = (message, sender, respond) => {
    if (!isAlive() || sender.id !== runtime.id) return false;
    if (message?.type === 'PING_WEB_BRIDGE') {
      respond({ ok: true, version: getVersion() });
      return false;
    }
    if (!['GET_APPLICATION_PREVIEW', 'GET_APPLICATION_CONTEXT', 'GET_APPLICATION_RESUME_FILE', 'SAVE_PROFILE_ANSWER', 'VERIFY_APPLICATION_CONTEXT', 'APPLICATION_DECISION'].includes(message?.type)) return false;
    const cleanup = () => {
      clearTimeout(timeout);
      window.removeEventListener('message', listener);
      pending.delete(cleanup);
    };
    const listener = event => {
      if (event.source !== window || event.origin !== location.origin || event.data?.source !== 'qiuzhi-apply-web' ||
          event.data.type !== 'SAVE_RESULT' || event.data.requestId !== message.requestId) return;
      cleanup(); respond(event.data);
    };
    const timeout = setTimeout(() => { cleanup(); respond({ ok: false, error: '工作台未响应，回答仍用于本轮，资料未保存。' }); }, ['APPLICATION_DECISION', 'SAVE_PROFILE_ANSWER'].includes(message.type) ? 100000 : 15000);
    pending.add(cleanup);
    window.addEventListener('message', listener);
    const extensionVersion = getVersion();
    window.postMessage({ ...message, ...(extensionVersion ? { extensionVersion } : {}), source: 'qiuzhi-apply-extension' }, location.origin);
    return true;
  };
  const onWindowMessage = async event => {
    if (event.source !== window || event.origin !== location.origin) return;
    const request = event.data;
    if (request?.source !== 'qiuzhi-apply-web' || !['PING', 'START', 'PREVIEW', 'CLEAR_PREVIEW', 'PREVIEW_INVALIDATED'].includes(request.type) ||
        typeof request.requestId !== 'string' || request.requestId.length > 64) return;
    if (!isAlive()) { dispose(); return; }
    let result;
    try {
      const types = { PING: 'PING_WEB_APPLY', START: 'START_WEB_APPLY', PREVIEW: 'PREVIEW_WEB_APPLY', CLEAR_PREVIEW: 'CLEAR_WEB_PREVIEW', PREVIEW_INVALIDATED: 'INVALIDATE_WEB_PREVIEW' };
      const payload = { type: types[request.type] };
      if (request.type === 'START') Object.assign(payload, { requestId: request.requestId, job: request.job, context: request.context });
      if (request.type === 'PREVIEW') Object.assign(payload, { job: request.job, userId: request.userId });
      if (request.type === 'CLEAR_PREVIEW') payload.jobId = request.jobId;
      result = await runtime.sendMessage(payload);
    } catch {
      if (!isAlive()) { dispose(); return; }
      result = { ok: false, code: 'UNAVAILABLE' };
    }
    if (!isAlive()) return;
    const version = getVersion();
    window.postMessage({ source: 'qiuzhi-apply-extension', requestId: request.requestId,
      ok: result?.ok === true, code: result?.code, ...(version ? { version } : {}) }, location.origin);
  };
  window.__qiuzhiApplyBridge = { isAlive, dispose };
  runtime.onMessage.addListener(onRuntimeMessage);
  window.addEventListener('message', onWindowMessage);
})();
