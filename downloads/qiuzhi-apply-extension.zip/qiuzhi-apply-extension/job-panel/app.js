(() => {
  const { siteFor } = globalThis.JobApplySitePolicy;
  const { actionProgress } = globalThis.JobApplyProgressCopy;
  const $ = id => document.getElementById(id);
  const ui = {
    connection: $('connection'), resumeName: $('resume-name'), resumeMeta: $('resume-meta'),
    fileCheck: $('file-check'), stepCounter: $('step-counter'), statusTitle: $('status-title'),
    statusMessage: $('status-message'), flowPulse: $('flow-pulse'), progress: $('progress-fill'),
    events: $('event-list'), start: $('start-button'), stop: $('stop-button'),
  };
  // Only locally authored messages may be shown as errors; transport/model details stay in diagnostics.
  class PanelError extends Error {}
  let settings;
  let facts;
  let activeTabId;
  let running = false;
  let webLaunch;
  let panelWindowId;
  let acceptingLaunch = false;
  let preparing = false;
  let readinessTimer;
  let preparationNumber = 0;
  let readinessAttempts = 0;
  let checkpoint;
  let restoring = false;
  let checkpointResolve;
  let rebindTarget;

  // 本地调试日志：各阶段耗时与错误栈。只有配对配置 debug=true 时后台才发 debug.trace。
  const debugLines = [];
  const debugTotals = { 模型: 0, 观察: 0, 动作: 0, 保存: 0 };
  const debugBucket = { 模型决策: '模型', 规划: '模型', 观察页面: '观察', 批量前重扫页面: '观察', 本步动作合计: '动作', 保存进度: '保存' };
  function resetDebug() {
    debugLines.length = 0; for (const key of Object.keys(debugTotals)) debugTotals[key] = 0;
    $('debug-list').replaceChildren(); $('debug-summary').textContent = ''; $('debug-card').hidden = true;
  }
  function addDebug(step, raw) {
    if (settings?.debug !== true) return;
    let entry; try { entry = JSON.parse(raw); } catch { return; }
    const time = new Date().toLocaleTimeString('zh-CN', { hour12: false });
    const line = `${time} 第${step}步 ${entry.phase} ${entry.ms}ms${entry.detail ? ` · ${entry.detail}` : ''}`;
    debugLines.push(line); if (debugLines.length > 2000) debugLines.shift();
    const item = document.createElement('li'); item.textContent = line;
    if (entry.ms >= 3000 || /异常|出错/.test(entry.phase)) item.className = 'slow';
    const list = $('debug-list'); list.append(item); while (list.children.length > 400) list.firstChild.remove();
    const bucket = debugBucket[entry.phase];
    if (bucket) debugTotals[bucket] += entry.ms;
    $('debug-summary').textContent = Object.entries(debugTotals).map(([name, ms]) => `${name} ${(ms / 1000).toFixed(1)}s`).join(' · ');
    $('debug-card').hidden = false;
  }

  function diagnostic(phase, detail, step = 0) {
    if (settings?.debug && detail) addDebug(step, JSON.stringify({ phase, ms: 0, detail: String(detail) }));
  }

  function showReview(entries) {
    const list = $('review-list'); list.replaceChildren();
    const labels = { filled: '已填写', preserved: '已保留', skipped: '已跳过', deferred: '待你完成', failed: '待核对', pending: '待处理' };
    for (const entry of entries || []) {
      const item = document.createElement('li');
      item.textContent = `${labels[entry.status] || '待核对'} · ${entry.label}：${entry.actualValue || '未填写'}`;
      list.append(item);
    }
    $('review-card').hidden = !list.children.length;
  }

  function showCheckpoint(saved) {
    checkpoint = saved;
    $('checkpoint-card').hidden = !saved || running;
    if (!saved) return;
    $('checkpoint-description').textContent = `${saved.source.name} · ${new Date(saved.updatedAt).toLocaleString()} · ${saved.target.origin}`;
    showReview(saved.review);
  }

  function status(title, message, mode = '') {
    ui.statusTitle.textContent = title;
    ui.statusMessage.textContent = message;
    ui.flowPulse.className = `flow-pulse ${mode}`;
  }

  function connection(mode, label) {
    ui.connection.className = `connection ${mode}`;
    ui.connection.querySelector('span').textContent = label;
  }

  function addEvent(text) {
    if (!text) return;
    ui.events.querySelector('.empty-event')?.remove();
    const item = document.createElement('li');
    item.textContent = text.length > 145 ? `${text.slice(0, 145)}…` : text;
    ui.events.prepend(item);
    while (ui.events.children.length > 7) ui.events.lastElementChild.remove();
  }

  function setButton(text, disabled = false) {
    ui.start.querySelector('span').textContent = text;
    ui.start.disabled = disabled;
  }

  async function activeTab() {
    if (webLaunch) return chrome.tabs.get(webLaunch.tabId);
    if (activeTabId) return chrome.tabs.get(activeTabId);
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new PanelError('请先打开目标招聘岗位页面');
    activeTabId = tab.id;
    return tab;
  }

  async function loadFacts() {
    const modeResponse = await fetch(chrome.runtime.getURL('release-config.json'));
    const online = modeResponse.ok && (await modeResponse.json()).mode === 'online';
    if (online) settings = { debug: false };
    else {
    const configResponse = await fetch(chrome.runtime.getURL('demo_config.local.json'));
    if (!configResponse.ok) throw new PanelError('插件尚未准备好，请重新安装后重试。');
    settings = await configResponse.json();
    if (settings.base_url !== 'http://127.0.0.1:8765') throw new PanelError('插件连接异常，请重新安装后重试。');
    const healthResponse = await fetch(`${settings.base_url}/health`);
    if (!healthResponse.ok) throw new PanelError('暂时无法连接服务，请稍后重试。');
    const health = await healthResponse.json();
    if (!health.ready) throw new PanelError('服务尚未就绪，请稍后重试。');
    }
    const stored = await chrome.storage.session.get(['jobAgentWebLaunch', 'jobAgentLastLaunch']);
    const launch = webLaunch || stored.jobAgentWebLaunch || stored.jobAgentLastLaunch;
    if (!launch?.context || launch.windowId !== panelWindowId) throw new PanelError('请登录工作台，从岗位的一键投递按钮启动。');
    webLaunch = launch;
    facts = launch.context;
    ui.resumeName.textContent = facts.source?.name || '个人资料';
    ui.resumeMeta.textContent = facts.source ? '使用简历和个人资料填写' : '使用个人资料填写';
    ui.fileCheck.textContent = '✓';
    connection('ready', '已就绪');
    setButton('开始辅助填写');
  }

  let port;
  let agentReady;
  let resolveReady;
  let protocolReady = false;
  let taskId;
  let paused = false;
  let question;
  let answering = false;
  const dialog = $('question-dialog');
  const answerInput = $('question-answer');

  function showQuestion(value) {
    question = value;
    const manual = value.kind === 'manual_action';
    const replacement = Boolean(value.replacement);
    status(manual ? '等待你在网页操作' : replacement ? '请确认修改' : '请补充信息', '请处理下方问题后继续。');
    const replacements = value.replacements?.length ? value.replacements : replacement ? [{ ...value.replacement, field: value.field }] : [];
    $('question-title').textContent = replacement ? `是否修改以下 ${replacements.length} 项信息？` : value.question;
    // reason is agent context, not user-facing copy. Only replacement details need a second paragraph.
    $('question-reason').hidden = !replacement;
    $('question-reason').textContent = replacement
      ? replacements.map((item, index) => `第 ${index + 1} 处：${item.field?.label || '当前内容'}\n现有内容：${item.currentValue}\n改为：${item.proposedValue}`).join('\n\n')
      : '';
    $('save-profile-label').hidden = manual || replacement;
    $('save-profile-answer').checked = !manual && !replacement;
    $('question-answer-label').hidden = manual || replacement;
    answerInput.hidden = manual || replacement;
    $('question-options').hidden = manual || replacement;
    $('question-skip').hidden = manual;
    $('question-submit').textContent = replacement ? '确认替换并继续' : manual ? '我已完成，继续' : '继续填写';
    $('question-help').textContent = replacement ? '仅替换以上内容。' : manual ? '完成网页操作后，点击继续。' : '取消勾选则仅用于本次填写。';
    $('question-error').textContent = '';
    answerInput.value = '';
    $('question-options').replaceChildren();
    for (const option of value.options || []) {
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'answer-option'; button.textContent = option;
      button.addEventListener('click', () => { answerInput.value = option; answerInput.focus(); });
      $('question-options').append(button);
    }
    setButton(manual ? '查看待办，继续' : '补充信息后继续');
    if (!dialog.open) dialog.showModal();
    (manual || replacement ? $('question-submit') : answerInput).focus();
  }

  function connectAgent() {
    if (port) return port;
    protocolReady = false;
    agentReady = new Promise(resolve => { resolveReady = resolve; });
    port = chrome.runtime.connect({ name: 'side-panel-connection' });
    port.onDisconnect.addListener(() => {
      port = undefined;
      if (running) finish(false, '连接已断开，自动操作已停止。请重新开始，已填写的内容会保留。');
    });
    port.onMessage.addListener(event => {
      if (event.type === 'agent_ready' && event.protocol === 10) { protocolReady = true; resolveReady(true); return; }
      if (event.type === 'profile_answer_saved' || event.type === 'profile_answer_failed') {
        diagnostic(event.type, event.detail);
        addEvent(event.type === 'profile_answer_saved' ? '已保存到个人资料。' : '未能同步个人资料，回答仍用于本次填写。请到个人资料页检查。'); return;
      }
      if (event.type === 'checkpoint') { showCheckpoint(event.checkpoint); checkpointResolve?.(); checkpointResolve = undefined; return; }
      if (event.type === 'checkpoint_error') { diagnostic('保存进度异常', event.error); addEvent('进度暂未保存，请保持当前页面打开。'); return; }
      if (event.type === 'heartbeat_ack') return;
      if (event.type === 'task_busy') {
        const message = '请等它结束，或关闭那个窗口的侧栏后再试。';
        finish(false, message); status('另一个窗口正在辅助填写', message); return;
      }
      if (event.type === 'task_control' && event.taskId === taskId && running) {
        paused = event.paused;
        ui.stop.textContent = paused ? '继续操作' : '暂停操作';
        setButton(paused ? (question ? '补充信息后继续' : '继续填写') : '正在辅助填写…', !paused && !question);
        status(paused ? '已暂停' : '继续填写', paused ? '你可以修改网页，再继续填写。' : '正在检查申请表。', paused ? '' : 'running');
        return;
      }
      if (event.type === 'target_changed' && event.taskId === taskId && running) {
        activeTabId = event.tabId;
        if (webLaunch) webLaunch = { ...webLaunch, tabId: event.tabId };
        addEvent('已进入新的申请页面。');
        return;
      }
      if (event.type === 'answer_rejected') {
        answering = false; $('question-submit').disabled = false;
        $('question-skip').disabled = false;
        diagnostic('回答异常', event.error);
        $('question-error').textContent = '回答未被接受，请检查后重试。'; return;
      }
      if (event.type === 'answer_accepted') {
        if (event.questionId !== question?.id) return;
        question = undefined; answering = false;
        $('question-submit').disabled = false; $('question-skip').disabled = false;
        dialog.close(); setButton('正在辅助填写…', true);
        if (paused) { port.postMessage({ type: 'resume_task' }); paused = false; }
        ui.stop.textContent = '暂停操作';
        status('继续填写', '正在根据你的回答继续填写。', 'running'); return;
      }
      if (event.type === 'error') {
        if (!protocolReady) { resolveReady(false); return; }
        diagnostic('连接异常', event.error);
        finish(false, '暂时无法继续，请稍后重试。已填写的内容会保留。'); return;
      }
      if (event.data?.taskId !== taskId || !running) return;
      const details = event.data.details;
      if (event.state === 'debug.trace') { addDebug(event.data.step, details); return; }
      ui.stepCounter.textContent = '填写中';
      if (event.state === 'review.updated') {
        try { showReview(JSON.parse(details)); } catch { addEvent('核对清单读取失败，请核对官网表单。'); }
      } else if (event.state === 'user.question') {
        try { showQuestion(JSON.parse(details)); } catch { finish(false, '暂时无法显示问题，请重新开始。'); }
      } else if (event.state === 'act.start' && !paused && !question) {
        diagnostic('操作开始', details, event.data.step);
        const progress = actionProgress(details);
        status(progress.title, progress.detail, 'running');
      } else if (event.state === 'act.ok' || event.state === 'act.fail' || event.state === 'step.fail') {
        diagnostic(event.state, details, event.data.step);
        if (event.state !== 'act.ok') addEvent('这一步未完成，正在重新检查。');
      } else if (event.state === 'step.start' && !question && !paused) {
        status('正在检查申请表', '请稍候。', 'running');
      } else if (event.state === 'task.ok') {
        diagnostic('填写结束', details, event.data.step);
        finish(true, '请核对填写结果，再到官网提交。');
      } else if (event.state === 'task.partial') {
        diagnostic('未完成项', details, event.data.step);
        finish(false, '请查看下方清单，补充或核对未完成项。'); status('本轮尚有未完成项', '请查看下方清单，补充或核对未完成项。');
      } else if (event.state === 'task.fail' || event.state === 'task.cancel') {
        diagnostic(event.state, details, event.data.step);
        finish(false, event.state === 'task.cancel' ? '已填写的内容会保留。' : '暂时无法继续，已填写的内容会保留。你可以稍后重试。');
        void chrome.tabs.get(activeTabId).then(tab => {
          const site = siteFor(tab.url || '');
          if (site) { setButton('检查当前网站并继续'); }
        }).catch(() => {});
      }
    });
    port.postMessage({ type: 'hello', windowId: panelWindowId });
    return port;
  }
  setInterval(() => { if (port) port.postMessage({ type: 'heartbeat' }); }, 20000);

  function finish(success, details) {
    running = false; preparing = false; paused = false; question = undefined; answering = false;
    preparationNumber++; clearTimeout(readinessTimer);
    if (dialog.open) dialog.close();
    ui.stop.hidden = true;
    ui.stepCounter.textContent = success ? '已结束' : '已停止';
    ui.progress.classList.remove('indeterminate');
    ui.progress.style.width = success ? '100%' : '0%';
    status(success ? '本轮填写结束，请核对' : '操作已停止', String(details || '').slice(0, 1000), success ? 'done' : '');
    addEvent(success ? '申请尚未提交，请检查官网表单。' : details);
    setButton(success ? '重新检查当前表单' : '检查当前网站并继续');
    void releaseWebLaunch();
    if (port) port.postMessage({ type: 'get_checkpoint' });
  }

  async function begin() {
    if (question) { if (!dialog.open) dialog.showModal(); (question.kind === 'manual_action' ? $('question-submit') : answerInput).focus(); return; }
    if (running) {
      if (paused) {
        connectAgent().postMessage({ type: 'resume_task' }); paused = false;
        ui.stop.textContent = '暂停操作'; setButton('正在辅助填写…', true);
        status('继续填写', '正在检查申请表。', 'running');
      }
      return;
    }
    if (preparing) return;
    preparing = true;
    const currentPreparation = ++preparationNumber;
    try {
      if (!facts && !restoring) await loadFacts();
      const tab = rebindTarget || await activeTab();
      if (currentPreparation !== preparationNumber) return;
      activeTabId = tab.id;
      const site = siteFor(tab.url || '');
      // A newly-created tab can report no URL / about:blank while navigation commits.
      // Wait for its actual URL; do not read or control a guessed pending destination.
      if (!site && (tab.status === 'loading' || !tab.url || tab.url === 'about:blank')) {
        status('正在打开招聘网页', '页面就绪后会继续，请稍候。', 'running');
        setButton('等待网页打开…', true); ui.stop.hidden = false;
        if (++readinessAttempts > 30) throw new PanelError('网页仍未打开，请检查官网后点击重试。');
        clearTimeout(readinessTimer);
        readinessTimer = setTimeout(() => void begin(), 1000);
        return;
      }
      if (!site) throw new PanelError('请选择使用 HTTPS 的招聘官网链接。');
      readinessAttempts = 0;
      const granted = await chrome.permissions.contains({ origins: [site.pattern] });
      if (currentPreparation !== preparationNumber) return;
      if (!granted) {
        throw new PanelError('扩展的网站访问权限尚未启用。请在扩展管理页重新加载或启用扩展，并将网站访问权限设为“在所有网站上”，然后重试。');
      }
      // The target is fixed for the whole run; changing the active tab cannot redirect it.
      taskId = crypto.randomUUID();
      running = true; paused = false;
      $('checkpoint-card').hidden = true;
      if (restoring && checkpoint) {
        ui.resumeName.textContent = checkpoint.source.name;
        ui.resumeMeta.textContent = '继续使用上次的资料';
        ui.fileCheck.textContent = '✓';
      } else if (facts) {
        ui.resumeName.textContent = facts.source?.name || '个人资料';
        ui.resumeMeta.textContent = facts.source ? '使用简历和个人资料填写' : '使用个人资料填写';
      }
      if (!restoring) showReview([]);
      ui.events.replaceChildren(); resetDebug(); ui.stop.hidden = false; ui.stop.textContent = '暂停操作';
      ui.progress.classList.add('indeterminate');
      ui.progress.style.width = '35%';
      setButton('正在辅助填写…', true);
      status('正在准备填写', '正在读取简历和申请表。', 'running');
      connectAgent();
      const ready = await Promise.race([agentReady, new Promise(resolve => setTimeout(() => resolve(false), 4000))]);
      if (currentPreparation !== preparationNumber || !running) return;
      if (!ready) throw new PanelError('插件未响应，请在扩展管理页重新加载，再打开侧栏。');
      port.postMessage({ type: restoring ? 'restore_task' : 'new_task', task: '填写当前岗位网申', taskId, tabId: tab.id,
        checkpointId: restoring ? checkpoint?.taskId : undefined, rebind: Boolean(rebindTarget) });
    } catch (error) {
      diagnostic('启动异常', error?.message);
      finish(false, error instanceof PanelError ? error.message : '暂时无法开始，请检查招聘页面后重试。');
    }
    finally { preparing = false; restoring = false; rebindTarget = undefined; }
  }

  function sendAnswer(decision) {
    if (!question || answering) return;
    if (decision === 'answer' && question.replacement) decision = 'confirm_replace';
    const text = question.replacement || decision === 'defer' ? '' : question.kind === 'manual_action' ? '我已完成网页操作，请重新观察页面确认是否可以继续。' : answerInput.value.trim();
    if (decision === 'answer' && !text) {
      $('question-error').textContent = '请补充信息，或选择跳过这一项。'; answerInput.focus(); return;
    }
    answering = true; $('question-submit').disabled = true; $('question-skip').disabled = true;
    connectAgent().postMessage({ type: 'answer_user', taskId, saveToProfile: $('save-profile-answer').checked,
      answer: { questionId: question.id, decision, text } });
  }
  $('question-form').addEventListener('submit', event => { event.preventDefault(); sendAnswer('answer'); });
  $('question-skip').addEventListener('click', () => sendAnswer('skip'));
  function later() {
    // 留到最后由用户处理：记为待办，Agent 继续处理其余内容，不原地等待。
    if (question) { addEvent(`已记为待你完成：${question.question}`); sendAnswer('defer'); }
  }
  $('question-later').addEventListener('click', later);
  $('debug-copy').addEventListener('click', () => { void navigator.clipboard.writeText(debugLines.join('\n')).then(() => addEvent('调试日志已复制')); });
  dialog.addEventListener('cancel', event => { event.preventDefault(); later(); });
  ui.start.addEventListener('click', () => { void begin(); });
  $('restore-button').addEventListener('click', () => {
    if (!checkpoint || running) return;
    activeTabId = checkpoint.target.tabId;
    if (webLaunch) webLaunch = { ...webLaunch, tabId: activeTabId };
    restoring = true; void begin();
  });
  $('rebind-button').addEventListener('click', async () => {
    if (!checkpoint || running) return;
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !siteFor(tab.url || '')) return status('无法继续', '请先打开要继续填写的招聘官网。');
    if (!window.confirm(`将上次填写进度从 ${checkpoint.target.origin} 转到 ${new URL(tab.url).origin}，使用上次资料继续当前页面？请确认这是同一岗位的申请页面。`)) return;
    rebindTarget = tab; activeTabId = tab.id; restoring = true; void begin();
  });
  $('discard-button').addEventListener('click', () => { if (!running) connectAgent().postMessage({ type: 'discard_checkpoint' }); });
  ui.stop.addEventListener('click', () => {
    if (!running) { finish(false, '已停止等待，你可以稍后重试。'); return; }
    if (paused) { void begin(); return; }
    connectAgent().postMessage({ type: 'pause_task' }); paused = true;
    status('已暂停', '当前操作结束后暂停。你可以稍后继续。');
    ui.stop.textContent = '继续操作'; setButton(question ? '补充信息后继续' : '继续填写');
  });

  async function releaseWebLaunch() {
    if (!webLaunch) return;
    const launch = webLaunch;
    const stored = await chrome.storage.session.get('jobAgentWebLaunch');
    if (stored.jobAgentWebLaunch?.requestId === launch.requestId) {
      try {
        const tab = await chrome.tabs.get(launch.tabId);
        await chrome.storage.session.set({ jobAgentLastLaunch: { ...launch, lastKnownUrl: tab.url } });
      } catch { /* Closed tabs will not be reused. */ }
      await chrome.storage.session.remove('jobAgentWebLaunch');
    }
  }

  async function acceptWebLaunch(launch) {
    if (!launch || launch.windowId !== panelWindowId || acceptingLaunch || running || preparing) return false;
    acceptingLaunch = true;
    webLaunch = launch;
    facts = undefined;
    activeTabId = launch.tabId;
    document.querySelector('.hero-job strong').textContent = launch.title;
    document.querySelector('.hero-job small').textContent = `${launch.company} · 官网网申`;
    if (checkpoint?.target.jobId && checkpoint.target.jobId === launch.jobId && checkpoint.source.userId === launch.context?.userId) {
      showCheckpoint(checkpoint); acceptingLaunch = false;
      status('可恢复上次填写', '可以从上次停下的地方继续。'); return true;
    }
    try {
      await begin();
    } finally { acceptingLaunch = false; }
    return true;
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'session' && changes.jobAgentWebLaunch?.newValue)
      void acceptWebLaunch(changes.jobAgentWebLaunch.newValue);
  });

  async function init() {
    try {
      panelWindowId = (await chrome.windows.getCurrent()).id;
      connectAgent();
      await Promise.race([agentReady, new Promise(resolve => setTimeout(resolve, 4000))]);
      const received = new Promise(resolve => { checkpointResolve = resolve; });
      port.postMessage({ type: 'get_checkpoint' });
      await Promise.race([received, new Promise(resolve => setTimeout(resolve, 300))]);
      await loadFacts();
      const pending = await chrome.storage.session.get('jobAgentWebLaunch');
      if (await acceptWebLaunch(pending.jobAgentWebLaunch)) return;
      await activeTab();
    } catch (error) {
      connection('error', '需要检查');
      diagnostic('连接异常', error?.message);
      status('资料尚未就绪', error instanceof PanelError ? error.message : '暂时无法读取资料，请稍后重试。');
      setButton('重新连接');
    }
  }

  void init();
})();
